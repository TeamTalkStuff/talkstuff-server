<?php

namespace Modules\Users\Models;

use Illuminate\Database\Eloquent\Model;

class FriendRequest extends Model
{
    //
}
