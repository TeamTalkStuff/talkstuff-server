<?php 


// You can find the keys here : https://console.developers.google.com

return array(
    'KEY' => 'YOUR API KEY'
);