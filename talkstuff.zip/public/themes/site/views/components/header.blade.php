<header id="header" class="full-header bg-ts">
    <div class="uk-container" id="header-wrap">
        <div class="uk-flex uk-flex-middle" uk-grid>
            <nav class="uk-width-expand@m" id="primary-menu">
                <ul>
                    <li><a href="/"><div>Home</div></a></li>
                    <li><a href="/"><div>Talk-Talk</div></a></li>
                </ul>
            </nav>

            <div class="uk-width-auto uk-flex uk-flex-middle uk-flex-around secondary-nav-menu"
                 style="">
                <a href="">Login</a>
                <a href="">Register</a>
            </div>
        </div>
    </div>
</header><!-- #header end -->