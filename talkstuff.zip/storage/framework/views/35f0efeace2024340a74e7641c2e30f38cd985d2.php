<router-link tag="li" :to="{name : 'app.dashboard'}" class="bg-hover-darkGray">
    <a href="#" class="fg-white">
        <i class="uk-margin-small-right fa fa-home fa-2x uk-text-middle"></i>
        Dashboard
    </a>
</router-link>
<router-link tag="li" :to="{name : 'app.modules'}" class="bg-hover-darkGray">
    <a href="#" class="fg-white">
        <i class="uk-margin-small-right fa fa-cubes fa-2x uk-text-middle"></i>
        Modules
    </a>
</router-link>

<?php $__env->startSection('scripts'); ?>
    <script src="/themes/controlPanel/views/app/app.min.js"></script>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<?php $__env->stopSection(); ?>